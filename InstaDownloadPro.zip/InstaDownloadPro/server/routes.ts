import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { instagramContentPreviewSchema } from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // API endpoint to fetch Instagram content metadata based on URL
  app.post("/api/preview", async (req: Request, res: Response) => {
    try {
      // Validate request body
      const schema = z.object({
        url: z.string().url("Please provide a valid URL"),
      });
      
      const parsed = schema.safeParse(req.body);
      
      if (!parsed.success) {
        const errorMessage = fromZodError(parsed.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      const { url } = parsed.data;
      
      // Check if URL is from Instagram
      const instagramRegex = /(instagram\.com|instagr\.am)/i;
      if (!instagramRegex.test(url)) {
        return res.status(400).json({ message: "Please provide a valid Instagram URL" });
      }
      
      try {
        // Fetch Instagram content preview information
        // This simulates fetching data from Instagram API
        // In a real implementation, you would use actual Instagram API or web scraping techniques
        
        // Get type of content based on URL
        const type = getContentTypeFromUrl(url);
        
        // For demo purposes, we'll just create a preview based on the URL parts
        const username = extractUsernameFromUrl(url);
        
        // Choose different images based on content type
        let thumbnailUrl = "";
        let mediaUrl = "";
        
        if (type === "reel" || type === "video") {
          thumbnailUrl = "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=600&h=800&fit=crop";
          mediaUrl = "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=1080&h=1920&fit=crop";
        } else if (type === "photo") {
          thumbnailUrl = "https://images.unsplash.com/photo-1605034313761-73ea4a0cfbf3?w=600&h=800&fit=crop";
          mediaUrl = "https://images.unsplash.com/photo-1605034313761-73ea4a0cfbf3?w=1080&h=1920&fit=crop";
        } else if (type === "story" || type === "highlight") {
          thumbnailUrl = "https://images.unsplash.com/photo-1512470876302-972faa2aa9a4?w=600&h=800&fit=crop";
          mediaUrl = "https://images.unsplash.com/photo-1512470876302-972faa2aa9a4?w=1080&h=1920&fit=crop";
        } else if (type === "igtv") {
          thumbnailUrl = "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=600&h=800&fit=crop";
          mediaUrl = "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=1080&h=1920&fit=crop";
        }
        
        const previewData = {
          url,
          type,
          username,
          profilePicture: `https://ui-avatars.com/api/?name=${username}&background=random`,
          thumbnailUrl,
          mediaUrl,
          qualities: [
            { label: "HD (1080p)", value: "1080p" },
            { label: "HD (720p)", value: "720p" },
            { label: "Standard (480p)", value: "480p" },
            { label: "Low (360p)", value: "360p" }
          ]
        };
        
        // Validate response with zod schema
        const validatedPreview = instagramContentPreviewSchema.parse(previewData);
        
        return res.status(200).json(validatedPreview);
      } catch (error) {
        console.error("Error fetching Instagram content:", error);
        return res.status(500).json({ 
          message: "Failed to fetch Instagram content. Please try again or check if the content is private."
        });
      }
    } catch (error) {
      console.error("Error in preview endpoint:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // API endpoint to download Instagram content
  app.post("/api/download", async (req: Request, res: Response) => {
    try {
      // Validate request body
      const schema = z.object({
        url: z.string().url("Please provide a valid URL"),
        quality: z.string().optional(),
      });
      
      const parsed = schema.safeParse(req.body);
      
      if (!parsed.success) {
        const errorMessage = fromZodError(parsed.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      const { url, quality } = parsed.data;
      
      // Check if URL is from Instagram
      const instagramRegex = /(instagram\.com|instagr\.am)/i;
      if (!instagramRegex.test(url)) {
        return res.status(400).json({ message: "Please provide a valid Instagram URL" });
      }
      
      try {
        // In a real implementation, you would download the content from Instagram
        // For this demo, we'll just return a success message with download information
        
        const type = getContentTypeFromUrl(url);
        const username = extractUsernameFromUrl(url);
        const selectedQuality = quality || "1080p";
        
        // Get base image URL based on content type
        let baseImageUrl = "";
        
        if (type === "reel" || type === "video") {
          baseImageUrl = "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7";
        } else if (type === "photo") {
          baseImageUrl = "https://images.unsplash.com/photo-1605034313761-73ea4a0cfbf3";
        } else if (type === "story" || type === "highlight") {
          baseImageUrl = "https://images.unsplash.com/photo-1512470876302-972faa2aa9a4";
        } else if (type === "igtv") {
          baseImageUrl = "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4";
        } else {
          baseImageUrl = "https://images.unsplash.com/photo-1605034313761-73ea4a0cfbf3";
        }
        
        // Generate a download URL based on quality - using static images to avoid 404 errors
        let downloadUrl = `${baseImageUrl}?w=1080&h=1920&fit=crop`;
        
        // In a real implementation, you would have different URLs for different qualities
        // Here we're using static images instead of random ones to avoid 404 errors
        if (selectedQuality === "1080p") {
          downloadUrl = `${baseImageUrl}?w=1080&h=1920&fit=crop`;
        } else if (selectedQuality === "720p") {
          downloadUrl = `${baseImageUrl}?w=720&h=1280&fit=crop`;
        } else if (selectedQuality === "480p") {
          downloadUrl = `${baseImageUrl}?w=480&h=854&fit=crop`;
        } else if (selectedQuality === "360p") {
          downloadUrl = `${baseImageUrl}?w=360&h=640&fit=crop`;
        }
        
        // Return download info
        return res.status(200).json({ 
          success: true, 
          message: "Content ready for download",
          downloadUrl,
          type,
          username,
          quality: selectedQuality
        });
      } catch (error) {
        console.error("Error downloading Instagram content:", error);
        return res.status(500).json({ 
          message: "Failed to download Instagram content. Please try again or check if the content is private."
        });
      }
    } catch (error) {
      console.error("Error in download endpoint:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  const httpServer = createServer(app);
  return httpServer;
}

// Helper function to determine content type from URL
function getContentTypeFromUrl(url: string): string {
  if (url.includes("/reels/") || url.includes("/reel/")) {
    return "reel";
  } else if (url.includes("/tv/") || url.includes("/igtv/")) {
    return "igtv";
  } else if (url.includes("/stories/")) {
    return "story";
  } else if (url.includes("/highlights/")) {
    return "highlight";
  } else if (url.includes("/p/")) {
    // Posts can be either photos or videos, defaulting to photo
    return "photo";
  } else {
    // Default fallback
    return "photo";
  }
}

// Helper function to extract username from URL
function extractUsernameFromUrl(url: string): string {
  try {
    const urlObj = new URL(url);
    const pathParts = urlObj.pathname.split('/').filter(Boolean);
    
    // The first path segment is usually the username in Instagram URLs
    if (pathParts.length > 0) {
      return pathParts[0];
    }
    
    return "instagram_user";
  } catch (error) {
    return "instagram_user";
  }
}
