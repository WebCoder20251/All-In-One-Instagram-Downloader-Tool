import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Define the Instagram content type enum
export const ContentType = {
  REEL: "reel",
  VIDEO: "video",
  PHOTO: "photo",
  STORY: "story",
  HIGHLIGHT: "highlight",
  IGTV: "igtv",
} as const;

// Define the Instagram content schema
export const instagramContents = pgTable("instagram_contents", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  type: text("type").notNull(),
  content_id: text("content_id").notNull(),
  username: text("username"),
  media_url: text("media_url"),
  thumbnail_url: text("thumbnail_url"),
  metadata: jsonb("metadata"),
  created_at: text("created_at").notNull(),
});

// Define the insert schema for Instagram content
export const insertInstagramContentSchema = createInsertSchema(instagramContents).omit({
  id: true,
});

// Define response schema for Instagram content preview
export const instagramContentPreviewSchema = z.object({
  url: z.string(),
  type: z.enum([
    ContentType.REEL,
    ContentType.VIDEO,
    ContentType.PHOTO,
    ContentType.STORY,
    ContentType.HIGHLIGHT,
    ContentType.IGTV,
  ]),
  username: z.string().optional(),
  profilePicture: z.string().optional(),
  mediaUrl: z.string().optional(),
  thumbnailUrl: z.string().optional(),
  qualities: z.array(
    z.object({
      label: z.string(),
      value: z.string(),
    })
  ).optional(),
});

// Define types
export type InsertInstagramContent = z.infer<typeof insertInstagramContentSchema>;
export type InstagramContent = typeof instagramContents.$inferSelect;
export type InstagramContentPreview = z.infer<typeof instagramContentPreviewSchema>;

// Keep existing user schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
