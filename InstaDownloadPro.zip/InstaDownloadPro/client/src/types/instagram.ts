export interface InstagramContentPreview {
  url: string;
  type: ContentType;
  username?: string;
  profilePicture?: string;
  mediaUrl?: string;
  thumbnailUrl?: string;
  qualities?: Quality[];
}

export type ContentType = 'reel' | 'video' | 'photo' | 'story' | 'highlight' | 'igtv';

export interface Quality {
  label: string;
  value: string;
}

export interface DownloadResponse {
  success: boolean;
  message: string;
  downloadUrl: string;
  type: ContentType;
  username?: string;
  quality: string;
}
