import React from 'react';
import DownloadForm from '@/components/DownloadForm';
import { 
  Film, 
  Video, 
  Image, 
  PlayCircle, 
  Clock, 
  Star 
} from 'lucide-react';

const formats = [
  { 
    icon: <Film className="text-[hsl(var(--instagram-blue))] h-8 w-8" />, 
    label: 'Reels' 
  },
  { 
    icon: <Video className="text-[hsl(var(--instagram-purple))] h-8 w-8" />, 
    label: 'Videos' 
  },
  { 
    icon: <Image className="text-[hsl(var(--instagram-purple-2))] h-8 w-8" />, 
    label: 'Photos' 
  },
  { 
    icon: <PlayCircle className="text-[hsl(var(--instagram-pink))] h-8 w-8" />, 
    label: 'IGTV' 
  },
  { 
    icon: <Clock className="text-[hsl(var(--instagram-pink-2))] h-8 w-8" />, 
    label: 'Stories' 
  },
  { 
    icon: <Star className="text-[hsl(var(--instagram-red))] h-8 w-8" />, 
    label: 'Highlights' 
  },
];

export default function Hero() {
  return (
    <section className="pt-12 pb-24 px-4">
      <div className="container mx-auto text-center">
        <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-clip-text text-transparent gradient-bg">
          All-in-One Instagram Downloader Tool
        </h1>
        <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto">
          Download Anything. Anytime. Instantly.
        </p>
        <p className="text-lg text-gray-500 mb-12 max-w-2xl mx-auto">
          Reels | Videos | Photos | Stories | Highlights | IGTV<br />
          Sab kuch ek hi jagah, bina kisi hassle ke!
        </p>
        
        <div id="download-form">
          <DownloadForm />
        </div>
        
        {/* Supported Formats */}
        <div className="flex flex-wrap justify-center gap-4 md:gap-8 mb-16">
          {formats.map((format, index) => (
            <div key={index} className="flex flex-col items-center">
              <div className="w-16 h-16 md:w-20 md:h-20 bg-white shadow-md rounded-xl flex items-center justify-center mb-2">
                {format.icon}
              </div>
              <span className="text-sm font-medium">{format.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
