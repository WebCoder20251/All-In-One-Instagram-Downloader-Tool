import React, { useState } from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "Is it safe to use InstaSave?",
    answer: "Yes, InstaSave is completely safe to use. We don't require you to log in or provide any personal information. Our service simply helps you download publicly available content from Instagram."
  },
  {
    question: "Can I download private Instagram content?",
    answer: "No, our service only works with publicly available Instagram content. We cannot access or download private content, as this would violate Instagram's privacy policies."
  },
  {
    question: "Is there a limit to how many posts I can download?",
    answer: "We don't impose strict limits, but we do have fair usage policies to ensure the service remains available to everyone. For bulk downloading needs, please use our service responsibly."
  },
  {
    question: "What's the highest quality available for downloads?",
    answer: "We provide the highest quality available from the source. For videos, this is typically up to 1080p (Full HD), and for images, we deliver the highest resolution available."
  },
  {
    question: "Does InstaSave work on mobile devices?",
    answer: "Yes, InstaSave is fully optimized for mobile devices. You can download Instagram content directly to your smartphone or tablet with the same ease as on a desktop."
  },
  {
    question: "Is InstaSave free to use?",
    answer: "Yes, InstaSave is completely free to use. We don't charge any fees for downloading Instagram content, and there are no hidden costs or premium features."
  }
];

export default function FAQ() {
  return (
    <section id="faq" className="py-16 px-4 bg-[hsl(var(--instagram-light-gray))]">
      <div className="container mx-auto max-w-4xl">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
          <p className="text-lg text-gray-600">Get answers to the most common questions about our Instagram downloader.</p>
        </div>
        
        <div className="space-y-6">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="bg-white rounded-xl shadow-sm overflow-hidden mb-4">
                <AccordionTrigger className="px-6 py-4 hover:no-underline">
                  <span className="font-semibold text-lg text-left">{faq.question}</span>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6">
                  <p className="text-gray-600">{faq.answer}</p>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
