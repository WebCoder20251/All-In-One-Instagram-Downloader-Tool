import React from 'react';
import { Facebook, Twitter, Instagram } from 'lucide-react';

export default function SocialIcons() {
  return (
    <div className="flex space-x-4">
      <a 
        href="#" 
        className="text-gray-400 hover:text-white transition-colors" 
        aria-label="Facebook"
      >
        <Facebook className="h-5 w-5" />
      </a>
      <a 
        href="#" 
        className="text-gray-400 hover:text-white transition-colors" 
        aria-label="Twitter"
      >
        <Twitter className="h-5 w-5" />
      </a>
      <a 
        href="#" 
        className="text-gray-400 hover:text-white transition-colors" 
        aria-label="Instagram"
      >
        <Instagram className="h-5 w-5" />
      </a>
    </div>
  );
}
