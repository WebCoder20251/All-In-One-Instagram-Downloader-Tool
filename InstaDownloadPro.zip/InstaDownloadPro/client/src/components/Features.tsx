import React from 'react';
import { 
  Zap, 
  Shield, 
  Smartphone, 
  Gauge, 
  Paintbrush, 
  CheckCircle 
} from 'lucide-react';
import { motion } from 'framer-motion';

const features = [
  {
    icon: <Zap className="text-white text-xl" />,
    title: "1-Click Download",
    description: "Reels, Videos, Photos, Stories, IGTV aur Highlights turant download karein."
  },
  {
    icon: <Shield className="text-white text-xl" />,
    title: "No Login Required",
    description: "Safe aur secure downloading experience without any account creation."
  },
  {
    icon: <Smartphone className="text-white text-xl" />,
    title: "Mobile Friendly UI",
    description: "Sleek, Fast & Fully Animated Website accessible on any device."
  },
  {
    icon: <Gauge className="text-white text-xl" />,
    title: "Lightning Speed",
    description: "High-quality downloads in seconds with our optimized system."
  },
  {
    icon: <Paintbrush className="text-white text-xl" />,
    title: "Professional Look",
    description: "Clean design, smooth transitions, and engaging animations."
  },
  {
    icon: <CheckCircle className="text-white text-xl" />,
    title: "Universal Support",
    description: "Works with all Instagram content types and across all browsers."
  }
];

const featureVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: i * 0.1,
      duration: 0.4
    }
  })
};

export default function Features() {
  return (
    <section id="features" className="py-16 px-4 bg-[hsl(var(--instagram-light-gray))]">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">Why Choose InstaSave?</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Experience a powerful, professional, and beautifully animated Instagram downloader that stands out from the crowd.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              custom={index}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-50px" }}
              variants={featureVariants}
              className="feature-card bg-white p-6 rounded-xl shadow-md transition-all duration-300"
            >
              <div className="w-14 h-14 rounded-lg gradient-bg flex items-center justify-center mb-5">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
