import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowDown, Loader2, Instagram } from 'lucide-react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { isValidInstagramUrl } from '@/utils/validators';
import { InstagramContentPreview, DownloadResponse } from '@/types/instagram';

export default function DownloadForm() {
  const [url, setUrl] = useState('');
  const [quality, setQuality] = useState('1080p'); // Default to HD quality
  const [preview, setPreview] = useState<InstagramContentPreview | null>(null);
  const { toast } = useToast();

  // Preview mutation
  const previewMutation = useMutation({
    mutationFn: async (instagramUrl: string) => {
      const res = await apiRequest('POST', '/api/preview', { url: instagramUrl });
      return res.json() as Promise<InstagramContentPreview>;
    },
    onSuccess: (data) => {
      setPreview(data);
      toast({
        title: "Content found!",
        description: "Preview ready. You can now download the content.",
        variant: "default",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error fetching content",
        description: error.message || "Please check your URL and try again.",
        variant: "destructive",
      });
    }
  });

  // Download mutation
  const downloadMutation = useMutation({
    mutationFn: async ({ downloadUrl, selectedQuality }: { downloadUrl: string; selectedQuality: string }) => {
      const res = await apiRequest('POST', '/api/download', { 
        url: downloadUrl,
        quality: selectedQuality 
      });
      return res.json() as Promise<DownloadResponse>;
    },
    onSuccess: (data) => {
      toast({
        title: "Download started!",
        description: "Your content will be downloaded shortly.",
        variant: "default",
      });
      
      // Create a hidden anchor and trigger download
      if (data.downloadUrl) {
        const a = document.createElement('a');
        a.href = data.downloadUrl;
        a.download = `instagram-${data.type}-${Date.now()}.${data.type === 'photo' ? 'jpg' : 'mp4'}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        // NOTE: We don't reset the preview state anymore, 
        // so the preview remains visible after download
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Download failed",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!url.trim()) {
      toast({
        title: "URL required",
        description: "Please enter an Instagram URL",
        variant: "destructive",
      });
      return;
    }
    
    if (!isValidInstagramUrl(url)) {
      toast({
        title: "Invalid URL",
        description: "Please enter a valid Instagram URL",
        variant: "destructive",
      });
      return;
    }
    
    previewMutation.mutate(url);
  };

  const handleDownload = () => {
    if (preview) {
      downloadMutation.mutate({ 
        downloadUrl: preview.url,
        selectedQuality: quality
      });
    }
  };

  return (
    <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-lg overflow-hidden mb-16">
      <div className="p-6 md:p-8">
        <h2 className="text-2xl font-bold mb-6">Download Instagram Content</h2>
        <form onSubmit={handleSubmit} className="flex flex-col md:flex-row space-y-3 md:space-y-0 md:space-x-3">
          <div className="relative flex-1">
            <Input
              type="text"
              placeholder="Paste Instagram URL here (e.g., https://www.instagram.com/p/...)"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="flex-1 pl-10 h-12 border-2 focus-visible:ring-[hsl(var(--instagram-blue))]"
            />
            <Instagram className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
          </div>
          
          <Button 
            type="submit" 
            className="download-btn gradient-bg flex items-center justify-center h-12 text-base"
            disabled={previewMutation.isPending}
          >
            {previewMutation.isPending ? (
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
            ) : (
              <>
                <span>Download</span>
                <ArrowDown className="ml-2 btn-icon h-5 w-5" />
              </>
            )}
          </Button>
        </form>
        <div className="mt-4 flex items-center gap-2 flex-wrap">
          <p className="text-xs text-gray-500">Works with:</p>
          <span className="inline-flex items-center rounded-full bg-blue-100 px-2 py-0.5 text-xs font-medium text-blue-700">Reels</span>
          <span className="inline-flex items-center rounded-full bg-purple-100 px-2 py-0.5 text-xs font-medium text-purple-700">Posts</span>
          <span className="inline-flex items-center rounded-full bg-pink-100 px-2 py-0.5 text-xs font-medium text-pink-700">Stories</span>
          <span className="inline-flex items-center rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium text-red-700">Highlights</span>
          <span className="inline-flex items-center rounded-full bg-indigo-100 px-2 py-0.5 text-xs font-medium text-indigo-700">IGTV</span>
        </div>
      </div>
      
      {/* Preview Area */}
      {preview && (
        <div className="border-t border-gray-200 p-6 md:p-8">
          <h3 className="text-xl font-bold mb-4">Content Preview</h3>
          <div className="flex flex-col md:flex-row items-start gap-6">
            {/* Content Preview */}
            <div className="w-full md:w-1/2 bg-gray-100 rounded-lg overflow-hidden h-[300px] md:h-[400px] shadow-md border border-gray-100 relative">
              {preview.thumbnailUrl && (
                <img 
                  src={preview.thumbnailUrl} 
                  alt="Content preview" 
                  className="w-full h-full object-cover"
                />
              )}
              <div className="absolute top-3 right-3">
                <span className="inline-flex items-center rounded-full bg-black bg-opacity-70 px-2.5 py-1 text-xs font-medium text-white">
                  {preview.type === 'reel' || preview.type === 'video' || preview.type === 'igtv' ? 'Video' : 'Photo'}
                </span>
              </div>
            </div>
            
            {/* Content Info */}
            <div className="w-full md:w-1/2 bg-white p-4 rounded-lg">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 rounded-full bg-gray-200 overflow-hidden border-2 border-[hsl(var(--instagram-pink))]">
                  {preview.profilePicture && (
                    <img 
                      src={preview.profilePicture} 
                      alt="Profile" 
                      className="w-full h-full object-cover" 
                    />
                  )}
                </div>
                <div className="ml-3">
                  <p className="font-medium text-lg">@{preview.username || 'instagram_user'}</p>
                  <p className="text-xs text-gray-500">Original post on Instagram</p>
                </div>
              </div>
              
              <div className="space-y-4 mb-6">
                <div>
                  <p className="text-sm font-medium text-gray-500">Type</p>
                  <p className="font-medium capitalize">{preview.type}</p>
                </div>
                {preview.qualities && preview.qualities.length > 0 && (
                  <div>
                    <p className="text-sm font-medium text-gray-500">Quality</p>
                    <Select value={quality} onValueChange={setQuality}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select quality" />
                      </SelectTrigger>
                      <SelectContent>
                        {preview.qualities.map((q, index) => (
                          <SelectItem key={index} value={q.value}>
                            {q.label}
                            {(q.value === "1080p" || q.value === "720p") && (
                              <span className="ml-2 inline-flex items-center rounded-full bg-green-100 px-1.5 py-0.5 text-xs font-medium text-green-700">
                                HD
                              </span>
                            )}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-gray-500 mt-1">
                      Choose HD quality for best results
                    </p>
                  </div>
                )}
              </div>
              
              <div className="space-y-3">
                <Button 
                  onClick={handleDownload} 
                  className="w-full gradient-bg h-12 text-lg"
                  disabled={downloadMutation.isPending}
                >
                  {downloadMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      <span>Processing...</span>
                    </>
                  ) : (
                    <>
                      <ArrowDown className="mr-2 h-5 w-5" />
                      <span>Download {quality === "1080p" ? "HD (1080p)" : 
                             quality === "720p" ? "HD (720p)" :
                             quality === "480p" ? "SD (480p)" :
                             quality === "360p" ? "SD (360p)" : 
                             "Now"}
                      </span>
                    </>
                  )}
                </Button>
                <p className="text-center text-xs text-gray-500">Free download, no login required</p>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Loading State */}
      {previewMutation.isPending && !preview && (
        <div className="border-t border-gray-200 p-8">
          <div className="flex flex-col items-center justify-center py-8">
            <div className="relative w-20 h-20 mb-5">
              <div className="absolute inset-0 rounded-full border-4 border-gray-200"></div>
              <div className="absolute inset-0 rounded-full border-4 border-t-transparent border-r-[hsl(var(--instagram-blue))] border-b-[hsl(var(--instagram-purple))] border-l-[hsl(var(--instagram-pink))] animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-12 h-12 rounded-full gradient-bg"></div>
              </div>
            </div>
            <h3 className="text-lg font-semibold mb-2">Fetching Instagram Content</h3>
            <p className="text-gray-600 mb-4">Please wait while we process your request...</p>
            
            <div className="flex space-x-3 mt-2">
              <div className="loading-dot w-3 h-3 bg-[hsl(var(--instagram-blue))] rounded-full animate-bounce"></div>
              <div className="loading-dot w-3 h-3 bg-[hsl(var(--instagram-purple-2))] rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              <div className="loading-dot w-3 h-3 bg-[hsl(var(--instagram-pink-2))] rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
