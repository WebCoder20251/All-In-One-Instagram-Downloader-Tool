import React, { useState } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Instagram } from 'lucide-react';
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Menu } from 'lucide-react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <header className="w-full">
      <div className="gradient-bg text-white py-2">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm font-medium">Download Instagram content faster than ever! No sign-up required.</p>
        </div>
      </div>
      <nav className="bg-white shadow-sm py-4">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <Link href="/" className="flex items-center cursor-pointer">
            <Instagram className="text-[hsl(var(--instagram-blue))] h-6 w-6 mr-2" />
            <span className="font-bold text-xl">InstaSave</span>
          </Link>
          <div className="hidden md:flex space-x-6">
            <button 
              onClick={() => scrollToSection('features')} 
              className="font-medium hover:text-[hsl(var(--instagram-blue))] transition-colors"
            >
              Features
            </button>
            <button 
              onClick={() => scrollToSection('how-it-works')} 
              className="font-medium hover:text-[hsl(var(--instagram-blue))] transition-colors"
            >
              How It Works
            </button>
            <button 
              onClick={() => scrollToSection('faq')} 
              className="font-medium hover:text-[hsl(var(--instagram-blue))] transition-colors"
            >
              FAQ
            </button>
          </div>
          <Button 
            onClick={() => scrollToSection('download-form')} 
            className="hidden md:block gradient-bg"
          >
            Get Started
          </Button>
          
          <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" className="md:hidden">
                <Menu />
              </Button>
            </SheetTrigger>
            <SheetContent>
              <div className="flex flex-col space-y-4 mt-8">
                <Button 
                  variant="ghost" 
                  onClick={() => scrollToSection('features')}
                >
                  Features
                </Button>
                <Button 
                  variant="ghost" 
                  onClick={() => scrollToSection('how-it-works')}
                >
                  How It Works
                </Button>
                <Button 
                  variant="ghost" 
                  onClick={() => scrollToSection('faq')}
                >
                  FAQ
                </Button>
                <Button 
                  onClick={() => scrollToSection('download-form')} 
                  className="gradient-bg"
                >
                  Get Started
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </nav>
    </header>
  );
}
