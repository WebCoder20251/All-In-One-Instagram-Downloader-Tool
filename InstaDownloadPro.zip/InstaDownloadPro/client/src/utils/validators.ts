/**
 * Validates if a URL is from Instagram
 * @param url URL to validate
 * @returns boolean indicating if URL is valid
 */
export function isValidInstagramUrl(url: string): boolean {
  if (!url || typeof url !== 'string') return false;
  
  // First, check if it's a valid URL format
  try {
    new URL(url);
  } catch (error) {
    return false;
  }
  
  // Then, check if it's from Instagram domains
  const instagramRegex = /(instagram\.com|instagr\.am)/i;
  return instagramRegex.test(url);
}

/**
 * Get content type from Instagram URL
 * @param url Instagram URL
 * @returns ContentType or null if cannot determine
 */
export function getContentTypeFromUrl(url: string): string | null {
  try {
    const urlObj = new URL(url);
    const path = urlObj.pathname;
    
    if (path.includes('/reels/') || path.includes('/reel/')) {
      return 'reel';
    } else if (path.includes('/tv/') || path.includes('/igtv/')) {
      return 'igtv';
    } else if (path.includes('/stories/')) {
      return 'story';
    } else if (path.includes('/highlights/')) {
      return 'highlight';
    } else if (path.includes('/p/')) {
      return 'photo'; // Could be photo or video, default to photo
    }
    
    return null;
  } catch (error) {
    return null;
  }
}
